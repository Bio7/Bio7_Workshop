#Plot selection coordinates in Java coordinates!
#Action to transfer simple selections without the ROI Manager.
#Image-Methods dialog->Points
#Plot in ImageJ (Java) coordinates.
plot(selectionx,selectiony,xlim=c(1,imageSizeX),ylim=c(imageSizeY,1))
