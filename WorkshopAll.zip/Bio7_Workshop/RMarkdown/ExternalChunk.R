
x<-runif(100)
print(x)
boxplot(x)
plot(x)