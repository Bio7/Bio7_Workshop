#Convert SpatialPoints to spatstat points (ppp) object.
library(maptools)
library(spatstat)
pointsPPP<-as(spatialPoints, "ppp")

