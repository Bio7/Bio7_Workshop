#RScript - please enter your code here !

packagesIJWorkshop<-c("knitr","formatR","rmarkdown","sp", "maptools", "rgdal", "spatstat","raster","ggplot2")
install.packages(packagesIJWorkshop, dep=TRUE, repos="http://cran.us.r-project.org")