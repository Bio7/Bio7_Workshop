#RScript - please enter your code here !
library(raster)

require(grDevices)
#convert the RGB matrix to a color object with alpha value!
rgbImage<-rgb(imageMatrix[,1]/255,imageMatrix[,2]/255,imageMatrix[,3]/255,1.0)

rgbMat<-matrix(rgbImage,nrow=imageSizeY,ncol=imageSizeX,byrow=TRUE)

rgbMatFinal <- apply(rgbMat, 2, rev)#Flip the matrix horizontally!
#Neccessary on MacOSX?
#Else try:
#rgbMatFinal <-rgbMat

image <- as.raster(rgbMatFinal)
#Create a plot with ImageJ (Java coordinates).
plot(c(0, imageSizeX), c(0, imageSizeY), xlim=c(0,imageSizeX),ylim=c(imageSizeY,0),type = "n", xlab = "", ylab = "")

plot(image,add=T)
